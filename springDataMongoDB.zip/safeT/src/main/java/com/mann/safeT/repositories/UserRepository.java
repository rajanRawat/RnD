package com.mann.safeT.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.mann.safeT.entities.UserInfo;

@Repository
public interface UserRepository extends MongoRepository<UserInfo, String> {

}
