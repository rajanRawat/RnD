package com.mann.safeT.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mann.safeT.entities.UserInfo;
import com.mann.safeT.repositories.UserRepository;

@RestController
@RequestMapping(value = "api/v1/users")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<UserInfo> getAllUsers() {
		return userRepository.findAll();
	}
}
